﻿$("#submitButton").click( function () {
    var assignments = parseInt($("#assignments").val());
    var groupprojects = parseInt($("#groupprojects").val());
    var quizzes = parseInt($("#quizzes").val());
    var exams = parseInt($("#exams").val());
    var intex = parseInt($("#intex").val());
    var lettergrade;
    var grade = (assignments * .5 + groupprojects*.1 + quizzes*.1 + exams*.2 + intex*.1);

   if (grade >= 90) {
        lettergrade = 'A';
    }
    else if (grade >= 80) {
        lettergrade = 'B';
    }
    else if (grade >= 70) {
        lettergrade = 'C';
    }
    else if (grade >= 60) {
        lettergrade = 'D';
    }
    else {
        lettergrade = 'F';
    }
    alert(assignments);
    alert('You will get a ' + grade + '% in the class and have an ' + lettergrade);
});